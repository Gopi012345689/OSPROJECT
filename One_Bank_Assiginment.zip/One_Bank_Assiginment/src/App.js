import logo from './logo.svg';
import Homepage from './Homepage/Homepage'
function App() {
  return (
    <>
    <Homepage/>
    </>
  );
}

export default App;
