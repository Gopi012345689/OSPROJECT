import React,{ useState,useEffect } from "react";
import "./Homepage.css";
import Typewriter from "typewriter-effect";
import logo from "../assest/logo_onebanc.png";
import { makeStyles } from "@material-ui/core/styles";
import ArrowForwardRoundedIcon from "@material-ui/icons/ArrowForwardRounded";
import TextField from "@material-ui/core/TextField";
import appStore from "../assest/appStore.png";
import img1 from "../assest/regular_bank.png";
import img2 from "../assest/onebanc_man.png";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      // width: "100%",
      width:'300px',
      marginTop: "7px",
      backgroundColor: "#fff",
      borderRadius:'0px'
    },
  },
}));

const Homepage = () => {
  const classes = useStyles();
  const [mail, setMail] = useState("");
  const [error, setError] = useState("");
  const [mailResponse, setMailResponse] = useState(false);

  const checkValidity=(data)=>{
    let isValid=true;
    const pattern = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
		isValid = pattern.test(data) && isValid;
    return isValid
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    if (mail == "") {
      setError("Required");
    } else if(mail!==""){
      if(checkValidity(mail)){
      setError("");
      setMailResponse(true)}
      else{
        setError("Invalid")
      }
    }
  };

  useEffect(()=>{
    setMailResponse(false)
  },[])
  return (
    <div class="homepage-main-parent">
      <div class="onebanc-left">
        <img src={logo} alt="oneBank-logo" class="logo-style" />
        <div class="page-moto">
          RE:
        <br/>
          THINK
          
          <Typewriter
            options={{
              strings: [
                "SUPPORT",
                "REWARDS",
                "SAVINGS",
                "INVESTMENTS",
                "FOREX",
                "PAYMENTS",
                "ANALYTICS",
                "CARDS",
                "LOAN",
              ],
              autoStart: true,
              loop: true,
              pauseFor: "300ms",
            }}
          />
        </div>
        <p class="page-para">
          We are a Neo Bank and are here to re-imagine and re-invent Banking. We
          are cool and simply awesome!
        </p>
        <div class="email-box">
          {!mailResponse ? (
            <>
              <span>Get an early invitation for our Beta release.</span>
              <div class="textField">
                <TextField
                  id="outlined-basic"
                  size="small"
                  value={mail}
                  onChange={(e) => {
                    setMail(e.target.value);
                  }}
                  placeholder="Enter Email Address"
                  variant="outlined"
                  className={classes.root}
                  InputProps={{
                    endAdornment: error && (
                      <span position="end" class="error">
                        {error}
                      </span>
                    ),
                  }}
                />
                <span class="arrow">
                  <ArrowForwardRoundedIcon
                    onClick={handleSubmit}
                    style={{
                      backgroundColor: "aqua",
                      height: "36px",
                      width: "60px",
                      marginTop: "7px",
                      cursor: "pointer",
                    }}
                  />
                </span>
              </div>
            </>
          ):<span style={{padding:'10px 0',display:'flex',justifyContent:'center'}}>Thanks for your interest<br/>
          we will get back to you soon</span>}
        </div>
        <img src={appStore} alt="qr-code" class="qr-code" />
        <div style={{ marginTop: "32px" }}>
          <span class="tc">Terms & Conditions | Privacy Policy</span>
          <br />
          <span class="bank-name">2021 © OneBanc Technologies Pvt. Ltd.</span>
        </div>
        
      </div>
   
      <div class="onebanc-right">
        <div>
          <img src={img1} alt="regular_bank" style={{width:'100%',marginTop:'10px'}}/>
          <p class="manText">#RegularBank</p>
        </div>
        <div class="vl"></div>
        <div>
          <img src={img2} alt="one_bank" style={{width:'100%'}}/>
          <p class="manText">#OneBanc</p>
        </div>
      </div>
    </div>
  );
};

export default Homepage;
